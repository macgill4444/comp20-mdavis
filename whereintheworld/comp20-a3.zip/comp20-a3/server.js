// Express initialization
var express = require('express');
var app = express();

//should set CORS for all 
app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

//to include assets file 
app.use('/public',express.static(__dirname + '/public'));
//to parse url 
var bodyParser = require('body-parser')
var url = require('url');
//parse url
app.use(bodyParser.urlencoded({ extended: true }))

// parse application/json
app.use(bodyParser.json())



// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/comp20'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var assert = require('assert');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
  if(error == undefined){
  	//console.log("successfully connected to db");
  }
});


//**********************************/

var insert_to_db = function(doc, callback) {
	// console.log(doc)
	db.collection('locations').insert(doc, function(err, result){
            if (err) {
                //console.log(err);
            } else {
                //console.log(result);
                callback(result)
            }
        });
}

var get_from_db = function (doc, callback) {
	//console.log(doc)
	db.collection('locations').find(doc).toArray(callback);
}


//for sorting dates in js, got off stackoverflow
function sortResults(results, prop, desc) {
	results = results.sort(function(a,b){
	  if(desc) return new Date(b[prop]) - new Date(a[prop]);
	  else return new Date(a[prop]) - new Date(b[prop])
	});
	return results;
}
//**********************************/

//index
app.get('/', function (req, res) {
	var indexPage = '';
	 get_from_db({}, function(err, result){
            if (err) {
                // console.log(err);
                res(err);
            } else {
            	result = sortResults(result, 'created_at', true)
                //console.log(result);
				indexPage += "<!DOCTYPE HTML><html><head><title>Home Page</title></head><body><h1>List of Logins</h1>";
				for (var count = 0; count < result.length; count++) {
					var single_location = result[count]
					indexPage += "<p>" 
					for (var key in single_location) {
					    var attrName = key;
           				var attrValue = single_location[key];
						indexPage += attrName + " : " + attrValue + ", ";
					} 
					indexPage += "!</p>"
				}
				indexPage += "</body></html>"
	            res.send(indexPage);
            }
	 });
})

//**********************************/

//post to locations
//NEED TO: only return last 100 not all of them
app.post('/sendLocation', function (req, res) {
    var ulogin = req.body.login,
     	ulat = parseFloat(req.body.lat),
     	ulng = parseFloat(req.body.lng);
    var ucreated_at = new Date();
    if(ulogin != undefined && ulat != undefined && ulng != undefined) {
		insert_to_db({login:ulogin, lat:ulat, lng:ulng, created_at:ucreated_at}, function(result){
			//console.log(result);
			//return the characters and 100 sorted students		
			 get_from_db({}, function(err, result){
			        if (err) {
			            res(err);
			        } else {
			        	result = sortResults(result, 'created_at', true)

			        	//limit to 100 sorted
			        	var one_hundred_results = "";
						for (var count = 0; count < 100; count++) {
							if(result[count] != undefined) {
								one_hundred_results += result[count]
							}
						}
			            // console.log(result);
			            big_json = {characters:[], students: result}
						res.header('Access-Control-Allow-Origin', "*")	
			            res.status(200).json(big_json);
			        }
			 });

		});
    } else {
		res.header('Access-Control-Allow-Origin', "*")	
    	res.status(200).json([]);
    }
});

//**********************************/

//locations 
app.get('/locations.json', function (req, res) {
     var ulogin = req.query.login;
	if(req.query.login != undefined) {
		var url_parts = url.parse(req.url, true);
		var query = url_parts.query;	
		var ulogin = query.login
		get_from_db({login:ulogin}, function(err, data){
            if (err) {
                // console.log(err);
                res(err);
            } else {
            	// console.log(data)
            	data = sortResults(data,'created_at', true)
                res.status(200).json(data);
            }
        });
	} else {
		res.status(200).json([]);
	}
});

//**********************************/

//redline 
var requester = require('request');
app.get('/redline.json', function (req, res) {
	var url_mbta = 'http://developer.mbta.com/lib/rthr/red.json'

	requester(url_mbta, function(error, response){
		if(!error) {
			res.status(200).json(JSON.parse(response.body))
		}
	})
})

//**********************************/

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);