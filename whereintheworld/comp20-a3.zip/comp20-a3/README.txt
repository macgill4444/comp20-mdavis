Macgill Davis
Assignment 3


1. I believe everything has been implemented correctly.
2. I have not collaborated with anyone.
3. 8 hours
