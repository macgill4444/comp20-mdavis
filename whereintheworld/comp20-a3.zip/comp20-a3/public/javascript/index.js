$(document).ready(function(){

	function sendLocationThroughAjax() 
	{
		//$.post('https://comp20-a3-macgill-davis.herokuapp.com/sendLocation', { login: "LoisGriffin", lat : "42.123123", lng : "72.12312312"}, 
		$.post('http://localhost:3000/sendLocation', { login: "CarlKing", lat : "11.123123", lng : "43.12312312"}, 
	    function(returnedData){
	         console.log(returnedData);
		});
	}

	sendLocationThroughAjax();


	function locationsGet() 
	{
		//$.post('https://comp20-a3-macgill-davis.herokuapp.com/sendLocation', { login: "mchow"}, 
		$.get('http://130.64.133.62:3000/locations.json', { login: "mchow"}, 
	    function(returnedData){
	         console.log(returnedData);
		});
	}
});